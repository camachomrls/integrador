'use strict';

document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('create-profile-form');
    const errorMessage = document.getElementById('error-message');
    const successModal = document.getElementById('success-modal');
    const redirectButton = document.getElementById('modal-redirect-button');
    
    // 🎯 RUTA DE REDIRECCIÓN
    const menuMusicoPath = '/vistas/menuMusico.html';

    // 1. Manejar el envío del formulario
    form.addEventListener('submit', function (event) {
        event.preventDefault(); 

        hideError(); // Oculta errores anteriores

        const fields = {
            artistName: document.getElementById('artist-name').value,
            genre: document.getElementById('genre').value,
            location: document.getElementById('location').value,
            experience: document.getElementById('experience').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            biography: document.getElementById('biography').value,
        };

        // 2. Validar que no haya campos vacíos
        const emptyFields = validateFields(fields);

        if (emptyFields.length > 0) {
            // ✅ MOSTRAR VENTANA DE ERROR
            showError(`⚠️ ¡Faltan campos por llenar! Por favor, verifica: ${emptyFields.join(', ')}.`);
            return; 
        }

        // 3. Si todo es válido, simula el proceso de creación
        console.log('✅ Perfil listo para ser creado:', fields);
        
        // Simular creación asíncrona (1 segundo)
        setTimeout(() => {
            handleSuccess(); // ✅ MOSTRAR VENTANA MODAL DE ÉXITO
        }, 1000); 
    });

    // 4. Manejar el clic en el botón de la ventana modal
    redirectButton.addEventListener('click', redirectToMenu);

    // --- Funciones de Utilidad ---
    
    function validateFields(fields) {
        const empty = [];
        if (!fields.artistName.trim()) empty.push('Nombre Artista');
        if (!fields.genre.trim()) empty.push('Género');
        if (!fields.location.trim()) empty.push('Ubicación');
        if (!fields.experience.trim()) empty.push('Experiencia'); 
        if (!fields.email.trim()) empty.push('Correo');
        if (!fields.phone.trim()) empty.push('Teléfono');
        if (!fields.biography.trim()) empty.push('Biografía/Descripción');
        return empty;
    }

    function showError(message) {
        errorMessage.textContent = message;
        errorMessage.classList.add('visible');
    }

    function hideError() {
        errorMessage.classList.remove('visible');
    }

    function handleSuccess() {
        // Mostrar la ventana modal
        successModal.classList.remove('hidden');
    }

    function redirectToMenu() {
        // 🚀 Redirige al menú del músico
        window.location.replace(menuMusicoPath); 
    }
});