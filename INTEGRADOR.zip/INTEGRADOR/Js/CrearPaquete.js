document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('formCrearPaquete');
    const modalExito = document.getElementById('modalExito');
    const modalError = document.getElementById('modalError');
    const cerrarModales = document.querySelectorAll('.btn-cerrar-modal');
    const btnVolverPerfil = document.querySelector('.btn-volver-perfil'); 

    // Campo de imagen personalizado
    const fileInput = document.getElementById('imagen');
    const fileNameDisplay = document.querySelector('.file-name-display');
    const btnSelectFile = document.querySelector('.btn-select-file');

    // Función para mostrar un modal
    function mostrarModal(modalElement) {
        modalElement.classList.add('active');
    }

    // Función para ocultar todos los modales
    function ocultarModales() {
        modalExito.classList.remove('active');
        modalError.classList.remove('active');
    }

    // Manejador de clic para cerrar modales (solo para el de error)
    cerrarModales.forEach(btn => {
        btn.addEventListener('click', ocultarModales);
    });

    // Cierre del modal al hacer clic fuera
    window.addEventListener('click', (event) => {
        // Cierra solo si se hace clic fuera del contenido
        if (event.target === modalError || event.target === modalExito) {
            ocultarModales();
        }
    });

    // Manejo del envío del formulario
    form.addEventListener('submit', function(event) {
        event.preventDefault();

        // Validar que se ha seleccionado un archivo (opcional, pero buena práctica)
        if (fileInput.files.length === 0) {
            alert('Por favor, selecciona una imagen para el paquete.');
            return; 
        }

        console.log('Datos del formulario listos para enviar...');
        
        // Simulación: siempre exitosa para probar el modal de éxito
        const simulacionExitosa = true; 

        if (simulacionExitosa) {
            mostrarModal(modalExito);
            form.reset(); 
            fileNameDisplay.textContent = 'Subir imagen representativa'; 
            
            // Cierra el modal de éxito automáticamente después de 2 segundos
            setTimeout(() => {
                ocultarModales();
            }, 2000); 

        } else {
            // Esto se ejecutaría si la simulación fallara.
            mostrarModal(modalError);
        }
    });

    // ********** CORRECCIÓN SOLICITADA **********
    // Manejador para el botón "Volver al Perfil"
    if (btnVolverPerfil) {
        btnVolverPerfil.addEventListener('click', () => {
            // Redirige al archivo menuMusico.html
            window.location.href = 'menuMusico.html';
        });
    }

    // Lógica para el campo de imagen personalizado
    btnSelectFile.addEventListener('click', () => {
        fileInput.click(); 
    });

    fileInput.addEventListener('change', () => {
        if (fileInput.files.length > 0) {
            fileNameDisplay.textContent = fileInput.files[0].name;
        } else {
            fileNameDisplay.textContent = 'Subir imagen representativa';
        }
    });
});