import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { getFirestore, doc, addDoc, deleteDoc, onSnapshot, collection, query, setLogLevel } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

// Global variables provided by the environment
const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';
const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : {};
const initialAuthToken = typeof __initial_auth_token !== 'undefined' ? __initial_auth_token : null;

let db, auth, userId = null;
let isAuthReady = false;

// DOM references
const monthDisplay = document.getElementById('monthDisplay');
const calendarGrid = document.getElementById('calendarGrid');
const prevMonthBtn = document.getElementById('prevMonth');
const nextMonthBtn = document.getElementById('nextMonth');
const currentDateDisplay = document.getElementById('currentDateDisplay');
const addEventToggleBtn = document.getElementById('addEventToggleBtn');
const eventFormContainer = document.getElementById('eventFormContainer');
const eventForm = document.getElementById('eventForm');
const cancelFormBtn = document.getElementById('cancelFormBtn');
const eventsList = document.getElementById('eventsList');

// Form inputs
const eventDateInput = document.getElementById('eventDateInput');
const eventNameInput = document.getElementById('eventName');
const eventTimeInput = document.getElementById('eventTime');
const eventPlaceInput = document.getElementById('eventPlace');
const eventNoteInput = document.getElementById('eventNote');

// Calendar state
let currentDate = new Date();
let selectedDate = new Date(); 

const months = ["ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"];

/** Formats a date for display (e.g., "19 de octubre") */
function formatDateForDisplay(date) {
    if (isNaN(date.getTime())) return "Selecciona un día";
    return `${date.getDate()} de ${months[date.getMonth()].toLowerCase()}`;
}

/** Formats a date for database key (e.g., "2025-10-19") */
function formatDbDate(date) {
    if (isNaN(date.getTime())) return "";
    return `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}`;
}

// --- Firebase Initialization and Auth ---

async function initializeFirebaseAndAuth() {
    try {
        if (Object.keys(firebaseConfig).length > 0) {
            const app = initializeApp(firebaseConfig);
            db = getFirestore(app);
            auth = getAuth(app);
            setLogLevel('Debug');
            
            onAuthStateChanged(auth, async (user) => {
                if (!user) {
                    if (initialAuthToken) {
                        await signInWithCustomToken(auth, initialAuthToken);
                    } else {
                        await signInAnonymously(auth);
                    }
                    return; 
                }
                
                userId = user.uid;
                console.log("Firebase: User signed in with ID:", userId);
                isAuthReady = true;
                
                // Initial render
                selectedDate = new Date(); 
                renderCalendar();
                updateEventsPanel(selectedDate);
            });
        } else {
            console.error("Firebase config is missing. App will run without persistent storage.");
            isAuthReady = true;
            renderCalendar();
            updateEventsPanel(selectedDate);
        }
    } catch (error) {
        console.error("Error initializing Firebase:", error);
        isAuthReady = true;
        renderCalendar();
        updateEventsPanel(selectedDate);
    }
}

// --- Calendar Rendering Logic ---

/** Renders the calendar grid for the current month */
function renderCalendar() {
    // 1. Clear previous day cells
    while (calendarGrid.children.length > 7) {
        calendarGrid.removeChild(calendarGrid.lastChild);
    }

    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    monthDisplay.textContent = `${months[month]} ${year}`;

    // 2. Date calculation logic
    const firstDayOfMonth = new Date(year, month, 1).getDay(); // 0=Sun, 1=Mon...
    const lastDayOfMonth = new Date(year, month + 1, 0).getDate();
    // Adjust start index to start on Monday (0=Mon, 1=Tue...)
    let startDayIndex = (firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1); 

    // 3. Days from previous month (padding)
    const prevMonthLastDay = new Date(year, month, 0).getDate();
    for (let i = startDayIndex; i > 0; i--) {
        const day = prevMonthLastDay - i + 1;
        const cell = createDayCell(day, 'old-month', false, new Date(year, month - 1, day));
        calendarGrid.appendChild(cell);
    }

    // 4. Days of the current month
    for (let day = 1; day <= lastDayOfMonth; day++) {
        const date = new Date(year, month, day);
        const cell = createDayCell(day, '', true, date);
        calendarGrid.appendChild(cell);
    }

    // 5. Days from next month (padding)
    const totalDaysInGrid = calendarGrid.children.length - 7;
    const remainingCells = 42 - totalDaysInGrid;

    for (let day = 1; day <= remainingCells; day++) {
        const cell = createDayCell(day, 'next-month', false, new Date(year, month + 1, day));
        calendarGrid.appendChild(cell);
    }

    highlightSelectedDay();
    // Force event list update after calendar render (to draw dots)
    if (isAuthReady && userId) {
        updateEventsPanel(selectedDate, true); 
    }
}

/** Creates a single day cell element */
function createDayCell(day, extraClass, isCurrentMonth, date) {
    const cell = document.createElement('div');
    cell.className = `day-cell ${extraClass}`;
    cell.setAttribute('data-date', formatDbDate(date));
    cell.innerHTML = `<div class="day-content">${day}<div class="event-indicator" id="indicator-${formatDbDate(date)}"></div></div>`;

    if (isCurrentMonth) {
        cell.addEventListener('click', () => handleDayClick(date));
    }
    
    return cell;
}

/** Highlights the currently selected day */
function highlightSelectedDay() {
    // 1. Remove previous selection highlight
    document.querySelectorAll('.day-cell span.selected-day').forEach(el => {
        const parentCell = el.closest('.day-cell');
        if(parentCell) {
            const dayNumber = el.textContent;
            // Replace the <span> with its text content (the day number)
            el.replaceWith(document.createTextNode(dayNumber));
        }
    });
    
    // 2. Apply highlight to the new selected day
    const targetCell = calendarGrid.querySelector(`.day-cell[data-date="${formatDbDate(selectedDate)}"]`);
    if (targetCell && !targetCell.classList.contains('old-month') && !targetCell.classList.contains('next-month')) {
        
        const dayContentEl = targetCell.querySelector('.day-content');
        const dayNumberNode = dayContentEl ? dayContentEl.childNodes[0] : null; 
        
        if (dayNumberNode && dayNumberNode.nodeType === 3) { // Must be a text node
            const dayNumber = dayNumberNode.textContent;
            const wrapper = document.createElement('span');
            wrapper.className = 'selected-day';
            wrapper.textContent = dayNumber;
            dayNumberNode.replaceWith(wrapper);
        }
    }
}

/** Handles click on a calendar day */
function handleDayClick(date) {
    selectedDate = date;
    highlightSelectedDay();
    updateEventsPanel(selectedDate);
    // Hide the form when selecting a new day
    eventFormContainer.classList.add('hidden');
    eventForm.reset();
}

/** Navigates to the previous or next month */
function handleNavigation(direction) {
    currentDate.setMonth(currentDate.getMonth() + direction);
    
    // Adjust selectedDate if it moves out of the new month
    const newMonth = currentDate.getMonth();
    const newYear = currentDate.getFullYear();
    
    if (selectedDate.getMonth() !== newMonth || selectedDate.getFullYear() !== newYear) {
        // Keep the day if possible, otherwise clamp to the 1st
        const dayToKeep = selectedDate.getDate();
        const lastDayOfNewMonth = new Date(newYear, newMonth + 1, 0).getDate();
        const newDay = Math.min(dayToKeep, lastDayOfNewMonth);
        selectedDate = new Date(newYear, newMonth, newDay);
    } 

    renderCalendar();
    eventFormContainer.classList.add('hidden');
    eventForm.reset();
    updateEventsPanel(selectedDate);
}

// Navigation event listeners
prevMonthBtn.addEventListener('click', () => handleNavigation(-1));
nextMonthBtn.addEventListener('click', () => handleNavigation(1));

// --- Events and Firestore Logic ---

let unsubscribeEvents = null;

/** * Updates the events panel for the selected day and sets up the Firestore listener.
 * If forceAll is true, it forces the listener update, necessary after rendering the calendar.
 */
function updateEventsPanel(date, forceAll = false) {
    currentDateDisplay.textContent = formatDateForDisplay(date);
    
    // Enable/disable the Add Event button
    const isVisibleMonth = currentDate.getMonth() === date.getMonth() && currentDate.getFullYear() === date.getFullYear();
    addEventToggleBtn.disabled = !isVisibleMonth;
    
    // Determine if we need to set up a new listener (only needed on first load or manual navigation)
    if (!forceAll && unsubscribeEvents && isAuthReady) {
        // Listener is already active, no need to resubscribe unless forced
    } else if (unsubscribeEvents) {
        unsubscribeEvents();
    }
    
    // Start a new Firestore listener
    if (isAuthReady && userId) {
        const dbDate = formatDbDate(date);
        // Private collection path: /artifacts/{appId}/users/{userId}/events
        const eventCollectionRef = collection(db, 'artifacts', appId, 'users', userId, 'events');
        const q = query(eventCollectionRef); 
        
        unsubscribeEvents = onSnapshot(q, (snapshot) => {
            const allEvents = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            
            // 1. Filter and sort events for the selected day (for the panel)
            const dailyEvents = allEvents.filter(event => event.date === dbDate).sort((a, b) => (a.time > b.time) ? 1 : -1);

            renderDailyEvents(dailyEvents);
            
            // 2. Render indicators for ALL events in the calendar grid
            renderAllEventIndicators(allEvents);

        }, (error) => {
            console.error("Error listening to events in Firestore:", error);
            renderDailyEvents([]);
        });
    } else {
         eventsList.innerHTML = `<p class="no-events-message">Cargando datos...</p>`;
    }
}

/** Draws a dot on calendar days that have events */
function renderAllEventIndicators(allEvents) {
     // Clear all previous indicators
     document.querySelectorAll('.event-indicator').forEach(el => el.innerHTML = '');
     
     // Group events by date
     const eventsByDate = allEvents.reduce((acc, event) => {
         acc[event.date] = acc[event.date] || [];
         acc[event.date].push(event);
         return acc;
     }, {});
     
     // Draw indicators on the grid cells
     document.querySelectorAll('.day-cell').forEach(cell => {
         const dateStr = cell.getAttribute('data-date');
         const indicatorEl = document.getElementById(`indicator-${dateStr}`);
         
         if (indicatorEl && eventsByDate[dateStr] && eventsByDate[dateStr].length > 0) {
             indicatorEl.innerHTML = `<span class="event-dot dot-reserved"></span>`;
         }
     });
}

/** Renders the list of events for the selected day in the right panel */
function renderDailyEvents(events) {
    eventsList.innerHTML = '';
    
    if (events.length === 0) {
        eventsList.innerHTML = `<p class="no-events-message">No hay eventos para este día.</p>`;
        return;
    }
    
    events.forEach(event => {
        const item = document.createElement('div');
        item.className = 'event-item';
        item.innerHTML = `
            <button class="delete-event-btn" data-id="${event.id}" title="Eliminar evento"><i class="fas fa-trash-alt"></i></button>
            <strong>${event.name}</strong>
            <div class="event-time"><i class="fas fa-clock"></i> ${event.time}</div>
            <div class="event-place"><i class="fas fa-map-marker-alt"></i> ${event.place}</div>
            ${event.note ? `<p class="event-note">${event.note}</p>` : ''}
        `;
        eventsList.appendChild(item);
    });
    
    // Add event listener for deletion
    document.querySelectorAll('.delete-event-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const eventId = e.currentTarget.getAttribute('data-id');
            deleteEvent(eventId);
        });
    });
}

/** Deletes an event from Firestore */
async function deleteEvent(eventId) {
    if (!isAuthReady || !userId) {
        console.error("Auth not ready or userId missing. Cannot delete event.");
        return;
    }
    try {
        const docRef = doc(db, 'artifacts', appId, 'users', userId, 'events', eventId);
        await deleteDoc(docRef);
        console.log("Evento eliminado con ID:", eventId);
    } catch (error) {
        console.error("Error al eliminar el evento:", error);
    }
}

// --- Inline Form Logic ---

addEventToggleBtn.addEventListener('click', () => {
    if (addEventToggleBtn.disabled) return;
    
    const isHidden = eventFormContainer.classList.contains('hidden');
    
    if (isHidden) {
        eventFormContainer.classList.remove('hidden');
        // Set the hidden date input with the selected day's date
        eventDateInput.value = formatDbDate(selectedDate);
        eventNameInput.focus();
    } else {
        eventFormContainer.classList.add('hidden');
        eventForm.reset(); 
    }
});

cancelFormBtn.addEventListener('click', () => {
    eventFormContainer.classList.add('hidden');
    eventForm.reset();
});

eventForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    if (!isAuthReady || !userId) {
        console.error("Auth not ready. Cannot save event.");
        return;
    }

    const newEvent = {
        date: eventDateInput.value, 
        name: eventNameInput.value.trim(),
        time: eventTimeInput.value,
        place: eventPlaceInput.value.trim(),
        note: eventNoteInput.value.trim(),
        createdAt: new Date().toISOString()
    };

    // Hide and reset the form immediately
    eventFormContainer.classList.add('hidden');
    eventForm.reset(); 

    try {
        const eventCollectionRef = collection(db, 'artifacts', appId, 'users', userId, 'events');
        await addDoc(eventCollectionRef, newEvent);
        console.log("Evento guardado exitosamente:", newEvent.name);
    } catch (error) {
        console.error("Error al guardar el evento en Firestore:", error);
    }
});

// Application start on window load
window.onload = initializeFirebaseAndAuth;